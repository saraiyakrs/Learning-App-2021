import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.Rectangle; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Astronomy_Dictionary extends PApplet {

InteractInterface i = new InteractInterface();

Button b1, b2, b3, b4 ;
int scene =  1 ;

public void setup() {
  
  build();
}

public void draw() {
  background(0);

  if (scene == 1) {
    drawWindow();
    b1.draw();
    b2.draw();
  } else if (scene == 2) {
    b3.draw();
  
  }
  else if (scene == 3 ) {
    b4.draw();
 
  }
  
  if (scene == 3) {
   drawWindow2();
}
  if (scene == 2) {
   drawWindow3();
}
}


public void mouseReleased() {
  if (scene == 1) {
    if (b1.isClicked()) {
      scene = 3;
      println(b4.title);
    }
  }
    if (b2.isClicked()) {
      scene = 2;
      println(b2.title);
    } else if (scene == 2) {
      switch (scene) {
         
      
      }
      if (b3.isClicked()) {
        scene = 1; 
        println(b3.title);
        
      }
    }
    else if (scene == 3) {
      if (b4.isClicked()) {
        scene = 1; 
        println(b4.title);
      
    }

    }
  }





public void build() {
  b1 = new Button(0, 200, 720, 55, "Click here to learn more about the Sun!", 0xffa87732);
  b2 = new Button(720, 200, 720, 55, "Click here to learn more about the Planets!", 0xffa83232);
  b3 = new Button(0, 550, 310, 310, "Return to Main Menu", 0xff2200FF);
  b4 = new Button(0, 550, 310, 310, "Return to Main Menu", 0xff2200FF);

  
}

public void drawWindow() {
  fill(0xffa83232);
  rect(0, 0, displayWidth, 100);
  fill(0xffa87732);
  rect(0, 200, 720, 55);
  fill(0xffa83232);
  rect(720, 200, 720, 55);
  fill(0xfff5ef42);
  rect(800, 500, 720, 385);
  PImage img;
  img = loadImage("planets-distance-order-Sun.jpg");
  image(img, 0, 500, 700, 400);
  i.drawTitle();
  i.drawSubTitle1();
  i.drawSubTitle2();
  i.drawBasicInfo();
  build();

 
}


public void drawWindow2() {
  fill(0xffa83232);
  rect(0, 0, displayWidth, 150);
  fill(0xff283232);
  rect(800,150,720, 800);
  PImage img;
  img = loadImage("sun.jpg");
  image(img, 0, 200, 400, 400);
  i.drawSunTitle();
  i.drawSunInfo();
 
  
}

public void drawWindow3() {
   fill(0xffa83232);
  rect(0, 0, displayWidth, 150);
  fill(0xff283232);
  rect(800,300,720, 800);
  fill(0xffa83000);
  rect(0,150,160,160);
  fill(0xffa83000);
 rect(160,150,160,160);
  fill(0xffa83000);
 rect(320,150,160,160);
  fill(0xffa83000);
 rect(480,150,160,160);
  fill(0xffa83000);
 rect(640,150,160,160);
  fill(0xffa83000);
 rect(800,150,160,160);
  fill(0xffa83000);
 rect(960,150,160,160);
  fill(0xffa83000);
 rect(1120,150,160,160);
  fill(0xffa83000);
 rect(1280,150,160,160);
  fill(0xffa83000);
 rect(1440,150,160,160);
  PImage img; 
  img = loadImage("planets.en.jpg");
  image(img, 300, 390, 500, 500);
  i.drawPlanetTitle();
  i.drawPlanetInfo();
  i.drawMercuryTitle();
  i.drawVenusTitle();
  i.drawEarthTitle();
  i.drawMarsTitle();
  i.drawJupiterTitle();
  i.drawSaturnTitle();
  i.drawUranusTitle();
  i.drawNeptuneTitle();
  i.drawPlutoTitle();
}


public class Button {
  public int x, y, w, h;
  public int c;
  public String title, text;
  public Rectangle clickArea;
  public int fontSIZE;

  public Button(int x, int y, int w, int h, String title, int c) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.title = title;
    this.c = c;
    this.clickArea = new Rectangle(x, y, w, h);
    this.fontSIZE = 25;
  }

  public void setText(String text) {
    this.text = text;
  }

  public void draw() {
    fill(c);
    rect(x, y, w, h);
    fill(0);
    textSize(fontSIZE);
    textAlign(CENTER);
    text(title, x+w/2, y+h/2);
  }

  public boolean isClicked() {
    return this.clickArea.contains(mouseX, mouseY);
  }
}

public class InteractInterface {
  public void drawTitle() { 
    textSize(60);

    fill(255);
    text("Welcome to the Astronomy DICTONARY!", 700, 90);
  }
  public void drawSubTitle1() {
    textSize(30);

    fill(255);
    text("Learn More About the Sun!", 100, 250);
  }
  public void drawSubTitle2() {
    textSize(30); 
    fill(255);
    text("Learn More About the Planets", 800, 250);
  } 

  public void drawBasicInfo() {
    textSize(25);
    fill(0);
    text("The Solar System is the Sun and all objects that orbit it. It is orbited by massive objects like planets, asteroids, comets, etc. The Solar System is said to be around 4.6 billion years old.", 900, 550, 400, 400);
  }
  
  
  public void drawSunTitle() {
    textSize(60);
   fill(255);
   text("THE SUN", 700, 100);
    
  }
  
  public void drawSunInfo() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
    text("The sun is a star, a hot ball of glowing gases at the heart of our solar system. Its influence extends far beyond the orbits of distant Neptune and Pluto. Without the sun's intense energy and heat, there would be no life on Earth. And though it is special to us, there are billions of stars like our sun scattered across the Milky Way galaxy. If the sun were as tall as a typical front door, the Earth would be the size of a U.S. nickel. The temperature at the sun's core is about 27 million degrees Fahrenheit.       Average diameter: 864,000 miles, about 109 times the size of the Earth.       Rotation period at equator: About 27 days. Rotation period at poles: About 36 days. Surface temperature: 10,000 degrees Fahrenheit. Composition: Hydrogen, helium.", 900,200,400, 1000);
 

  }
  public void drawPlanetTitle() {
   textSize(60);
   fill(255);
   textAlign(CENTER);
   text("PLANETS OF THE SOLAR SYSTEM", 700, 100);
  }
  
  public void drawPlanetInfo() {
    textSize(15);
    fill(255);
    textAlign(CENTER);
    text("The smallest and fastest planet, Mercury is the closest planet to the Sun and whips around it every 88 Earth days.Spinning in the opposite direction to most planets, Venus is the hottest planet, and one of the brightest objects in the sky. The place we call home, Earth is the third rock from the sun and the only planet with known life on it - and lots of it too! Mars: The red planet is dusty, cold world with a thin atmosphere and is home to four NASA robots.Jupiter is a massive planet, twice the size of all other planets combined and has a centuries-old storm that is bigger than Earth. Saturn: The most recognizable planet with a system of icy rings, Saturn is a very unique and interesting planet. Uranus has a very unique rotation--it spins on its side at an almost 90-degree angle, unlike other planets. Neptune is now the most distant planet and is a cold and dark world nearly 3 billion miles from the Sun. Pluto will always be the ninth planet to us! Smaller than Earth's moon, Pluto was a planet up until 2006 and has five of its own moons! " ,900,325, 400, 1000);
   
  
  } 
  
  public void drawMercuryTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
    text("Mercury", 75,250);
    
    
    
  }
  public void drawVenusTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
      text("Venus", 225,250);
    
    
    
  }
  public void drawEarthTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
      text("Earth", 375,250);
    
    
    
  }
  public void drawMarsTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
      text("Mars", 550,250);
    
    
    
  }
  public void drawJupiterTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
      text("Jupiter", 725 ,250);
        
    
  }
  public void drawSaturnTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
      text("Saturn", 875 ,250);
    
    
    
  }
  public void drawUranusTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
   text("Uranus", 1050,250);   
    
    
    
  }
  public void drawNeptuneTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
     text("Neptune", 1205,250); 
    
    
    
  }
  public void drawPlutoTitle() {
    textSize(20);
    fill(255);
    textAlign(CENTER);
     text("Pluto", 1350 ,250); 
    
    
    
  }
}
  public void settings() {  size(1420, 890); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Astronomy_Dictionary" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
